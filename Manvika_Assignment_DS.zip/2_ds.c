///////--approach 1--///////


#include <stdio.h>
#include <string.h>

char queue[20][20], temp[20];
int front = -1, rear = -1;
void enqueue(char *ptr)
{
if(rear == 19)
   {
    return;
   }

if(front == -1 && rear == -1)
   {
   front = rear = 0;
   }

else
{
rear = rear + 1;
}

strcpy(queue[rear],ptr);
}

char* dequeue()
{
if(front == -1)
  {  
    printf("\nEmpty Queue");
  }
else
  {
  strcpy(temp,queue[front]);
  
if(front == rear)
  
  front = rear = -1;
  
else
 
  front = front + 1;
 
return temp;
}
}

void binary_num_gen_using_queue()
{
char temp2[20];
strcpy(temp,dequeue());
printf("%s ",temp);
strcpy(temp2,temp);
strcat(temp,"0");
enqueue(temp);
strcat(temp2,"1");
enqueue(temp2);
}

void main()
{
int i,n;
printf("\nEnter the end value : ");
scanf("%d",&n);
char temp[2] = "1";
enqueue(temp);
printf("\nBinary numbers from 1 to %d : \n\n",n);
for(i = 1; i <= n; i++)
binary_num_gen_using_queue();
printf("\n");
}


















////////-----approach 2(for future reference)------/////////




//#include<stdio.h>

/*
void binary(int );
void binary_generation(int);


void main()
{
int num;

printf("Enter the number n: ");
scanf("%d",&num);
printf("Binary is: ");
binary_generation(num);





}

void binary_generation(int num)
{

  int i;
  for(i=0;i<=num;i++)
	{
	    binary(i);	
	}



}




void binary(int n)
{
int i,c=0,a[20];

for(i=0;n>0;i++)
{
a[i]=n%2;    
n=n/2;  
c++;

}

for(i=i-1;i>=0;i--){
printf("%d", a[i]); 

}

}*/














#include<stdio.h>

void merge(int [], int [], int, int);


void main()
{

int n1,n2;
int X[]={1,4,7,8,10};
int Y[]={2,3,9};

n1=sizeof(X)/sizeof(X[0]);
n2=sizeof(Y)/sizeof(Y[0]);

merge(X,Y,n1,n2);


printf("X= ");
for(int i=0;i<n1;i++)
{
	printf("%d ",X[i]);
}


printf("\nY= ");
for(int i=0;i<n2;i++)
{
	printf("%d ",Y[i]);
}
}



void merge(int X[], int Y[], int n1, int n2)
{

for(int i=0;i<n1;i++)
{
	if(X[i]>Y[0])
	{
		int temp;
		temp= X[i];
		X[i]=Y[0];
		Y[0]=temp;

		int first= Y[0];

		int k;
		for(k=1; k<n2 && Y[k]<first;k++)
		{
			Y[k-1]=Y[k];
		}		

	Y[k-1]=first;
		
	}

}

}

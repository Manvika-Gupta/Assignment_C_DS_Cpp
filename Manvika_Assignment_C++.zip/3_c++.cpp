#include<iostream>
using namespace std;

class AddAmount

{

private: int amount = 50;

public:

 AddAmount()

{

}

 AddAmount(int a)

{

amount = a+amount;

}

 void displayAmount()

{

cout << amount;

}

};

int main()
{
int amt;
AddAmount a;


cout<<"Initial amount in the Piggy Bank: Rs.";
a.displayAmount();
cout<<"\nEnter the amount you want to enter into the Piggy Bank: ";
cin >>amt;
AddAmount b(amt);
cout<<"Final amount in the Piggy Bank: Rs.";
b.displayAmount();
cout <<endl;

return 0;
}

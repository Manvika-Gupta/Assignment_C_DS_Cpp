#include<iostream>


using namespace std;


class Employee
{
	double salary;
	int no_of_hours;
public:
	Employee() {}
	void getinfo()
	{
		cout << "Enter the salary of employee: ";
		cin >> salary;
		cout << "Enter the number of hours: ";
		cin >> no_of_hours;
	}
	void AddSal()
	{
		if (salary < 500)
			salary += 10;
	}
	void AddWork()
	{
		if (no_of_hours > 6)
			salary += 5;
	}
	void DisplaySalary()
	{
		cout << salary;
	}


};


int main()
{
	int num;
	cout << "Enter the number of employees: ";
	cin >> num;

  Employee E[num];
	for (int i = 0; i < num; i++)
	{
		E[i].getinfo();
		E[i].AddSal();
		E[i].AddWork();
	}
	for (int i = 0; i < num; i++)
	{
		cout << "\nThe final salary of employee "<<i+1<<" is:";
		E[i].DisplaySalary();
		cout<<endl;
	}

return 0;
}

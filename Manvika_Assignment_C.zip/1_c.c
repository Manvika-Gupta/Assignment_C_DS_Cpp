#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct library
{
 int an;
 char author_name[30];
 char title[30];
 int price;
 int flag; //issued=1 else 0
 

}bk[50];//={1, "Lets Us C" , "Yashavant Kanethkar", 258 , 0};

void add_info();
void display_info();
void author_books(char name[]);
void view_title(int);
int count();
void orderby_an();


void main()
{

char name[20];
int op,num;
int no,n;
while(op!=7)
	{
	printf("\n\nWhat do you want to do?\n\n1.Add book information\n2.Display book information\n3.List all books of an author\n4.List the title of a book\n5.List the count of books in the library\n6.List the books in order of Accession number.\n7.Exit\n");
	scanf("%d",&op);
	
		switch(op)
		{

		case 1: 
		add_info();
		break;

		case 2:
		printf("Enter the accession number of the book to be displayed: ");
		scanf("%d",&n);		
		display_info(n);
		break;
	
		case 3:
		printf("Enter the name of the Author whose books are to be found: ");
		scanf("%s",name);
		author_books(name);	
		break;

		case 4:
		printf("Enter accession number of the book: ");
		scanf("%d",&no);
		view_title(no);
		break;			

		case 5:
		num = count();
		printf("The total number of books are: %d",num);
		break;

		case 6:
		orderby_an();
		break;

		case 7:
		printf("Thankyou! Bye Bye.\n");
		break;

		default:
		printf("Enter a valid option.");
		

	
		}	



	}



}



int count()
{

	int i=0;
	while(bk[i].an)
	{
	i++;
	}	

	return i;
}





void add_info()
{
int num=count();
bk[num].an=num+1;
printf("Enter the title of book: ");
scanf("%s",bk[num].title);
printf("Enter the author of book: ");
scanf("%s",bk[num].author_name);
printf("Enter price of the book: ");
scanf("%d", &bk[num].price);
bk[num].flag=0;


}




void display_info(int i)
{
i--;
int num=count();

for(int n=0;n<=num;n++)
{
	if(bk[i].an==bk[n].an)
		{
		printf("\nThe accession number of the book is: %d\n",bk[i].an);
		printf("The title of the book is: %s\n", bk[i].title);
		printf("The author of the book is: %s\n",bk[i].author_name);
		printf("The price of the book is: %d\n", bk[i].price);
		printf("The book status is:" );
		if(bk[i].flag==1)
			{
			printf(" issued");
			}
		else
			{
			printf(" not issued");
			}
	printf("\n");
	//printf("\n");
		break;		
		} //if ends
         



}//for ends 

}




void author_books(char name[])
{
int num =count();
int found=0;
for(int i=0;i<=num;i++)
{

	if(strcmp(name,bk[i].author_name)==0)
		{
                        printf("Books with the author '%s' are: ",name);
			printf("%s\n",bk[i].title);			
			found=1;
		}

}
if(found!=1)
printf("No such book found!");
}











void view_title(int no)
{
int i=0;
while(bk[i].an)
{

	if(bk[i].an==no)
	{
	printf("Title of the book is: %s ",bk[i].title);
	return;
	}

i++;
}
printf("No such book found!\n");
}


/*
void orderby_an()
{
int num=count();
printf("The books in order of their Accession numbers are:\n");
for(int i=0;i<=num;i++)
{
printf("%d %s\n",bk[i].an,bk[i].title);
printf("end");
}*/

void orderby_an()
{
	int i =0;
	while(bk[i].an)
	{
	printf("The books in order of their Accession numbers are:\n");
	display_info(i+1);
	i++;
	}



}


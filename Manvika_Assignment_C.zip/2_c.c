#include<stdio.h>


void percentage_total(int, int, int, float *, float * );


void main()
{
int a,b,c;
float total,perc;

printf("Enter marks of subject 1: ");
scanf("%d",&a);

printf("Enter marks of subject 2: ");
scanf("%d",&b);

printf("Enter marks of subject 3: ");
scanf("%d",&c);

	percentage_total(a,b,c, &total, &perc);


printf("\nThe total of subjects are: %f",total);
printf("\nThe percentage of subjects are: %f%%\n",perc);

}



void percentage_total(int a,int b, int c, float *total ,float *perc)
{

 *total = a+b+c; 

 *perc = (*total/300.0)*100;

}
